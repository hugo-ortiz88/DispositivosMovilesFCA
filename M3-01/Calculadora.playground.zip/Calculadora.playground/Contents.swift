import UIKit

let operacion:Int = readLine();

func suma(primerNumero:Float, segundoNumero:Float)  -> Float {return primerNumero + segundoNumero
}

func resta(minuendo: Float, sustraendo: Float) -> Float {
return minuendo - sustraendo}


func multipliacion(primerFactor: Float, segundoFactor: Float) -> Float {
    return primerFactor * segundoFactor
}

func division(divisor: Float, dividendo: Float) -> Float? {
    if dividendo == 0
    {return nil}
    return divisor / dividendo
}
print("Presiona 1 para sumar" \t "Presiona 2 para restar" \t "Presiona 3 para multiplicar" \t "Presiona 4 para sumar")
readLine(operacion);

if operacion != 0{
    switch operacion{
    case 1:
        print("Escribe el primer valor: ")
        readLine(primerNumero);
        suma(primerNumero: <#T##Float#>, segundoNumero: <#T##Float#>)
    case 2:
        resta(minuendo: <#T##Float#>, sustraendo: <#T##Float#>)
    case 3:
        multipliacion(primerFactor: <#T##Float#>, segundoFactor: <#T##Float#>)
    case 4:
        division(divisor: <#T##Float#>, dividendo: <#T##Float#>)
}

    	
}
